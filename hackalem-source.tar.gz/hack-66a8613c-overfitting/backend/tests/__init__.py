"""Skeleton contract checks."""
