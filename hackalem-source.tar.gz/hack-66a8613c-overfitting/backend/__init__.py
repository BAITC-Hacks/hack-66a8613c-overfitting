"""Local meeting minutes prototype."""
