"""Local meeting minutes prototype."""
