"""Skeleton contract checks."""
